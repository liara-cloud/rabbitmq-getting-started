const express = require('express');
const amqp = require('amqplib');
require('dotenv').config();

const app = express();

async function receiveMessage() {
    const rabbitmqHost = process.env.RABBITMQ_HOST;
    const rabbitmqPort = process.env.RABBITMQ_PORT;
    const rabbitmqUser = process.env.RABBITMQ_USER;
    const rabbitmqPassword = process.env.RABBITMQ_PASSWORD;

    const connection = await amqp.connect(`amqp://${rabbitmqUser}:${rabbitmqPassword}@${rabbitmqHost}:${rabbitmqPort}`);
    const channel = await connection.createChannel();
    const queueName = 'my_queue';

    await channel.assertQueue(queueName, { durable: false });

    console.log("Waiting for messages...");

    channel.consume(queueName, (message) => {
        console.log("Received message:", message.content.toString());
        // ارسال پیام دریافتی به صفحه وب
        io.emit('message', message.content.toString());
    }, { noAck: true });
}

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
});

const server = app.listen(3000, () => {
    console.log('Server is running on port 3000');
});

const io = require('socket.io')(server);

io.on('connection', (socket) => {
    console.log('A user connected');

    socket.on('disconnect', () => {
        console.log('User disconnected');
    });
});

receiveMessage().catch(console.error);
