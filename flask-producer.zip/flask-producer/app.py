from flask import Flask, render_template
import pika
from dotenv import load_dotenv
import os

app = Flask(__name__)
load_dotenv()

rabbitmq_host = os.getenv('RABBITMQ_HOST')
rabbitmq_port = int(os.getenv('RABBITMQ_PORT'))
rabbitmq_user = os.getenv('RABBITMQ_USER')
rabbitmq_password = os.getenv('RABBITMQ_PASSWORD')
queue_name = 'my_queue'

# authentication
print("RabbitMQ Host:", rabbitmq_host)
print("RabbitMQ Port:", rabbitmq_port)
print("RabbitMQ User:", rabbitmq_user)
print("RabbitMQ Password:", rabbitmq_password)

credentials = pika.PlainCredentials(rabbitmq_user, rabbitmq_password)
connection = pika.BlockingConnection(pika.ConnectionParameters(host=rabbitmq_host, port=rabbitmq_port, credentials=credentials))
channel = connection.channel()
channel.queue_declare(queue=queue_name)

def send_message(message):
    channel.basic_publish(exchange='', routing_key=queue_name, body=message)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/send_message', methods=['POST'])
def send():
    message = "Hi, I love Liara"
    send_message(message)
    return "Message sent successfully!"

if __name__ == '__main__':
    app.run(debug=True)
